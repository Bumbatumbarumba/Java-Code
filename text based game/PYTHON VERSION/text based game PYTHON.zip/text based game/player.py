#Bartosz Kosakowski
#Created on 12/07/16
########################

"""-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
this class handles all info related
to the player including position
and inventory
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"""
class player():
    def __init__(self):
        px = 0
        py = 0
        pz = 0
        playerInv = dict()
        playerInvDesc = dict()
    def showPlayerInv():
        
